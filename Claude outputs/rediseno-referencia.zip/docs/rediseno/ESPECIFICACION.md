# Rediseño del panel de Industrias Charly — Especificación de implementación

Este documento es la **fuente de verdad** del rediseño. Los mockups de `docs/rediseno/mockups/` son la referencia visual exacta (colores, tamaños, textos, distribución). Cuando un mockup y este documento no coinciden, **manda este documento** (la sección 9 lista cada caso resuelto).

---

## 0. Reglas generales (aplican a todas las fases)

1. **Fidelidad visual.** Replica los mockups: mismos colores hex, tamaños de fuente, radios, espaciados, textos y orden de columnas. Los mockups usan estilos en línea (`style="..."`) y datos de ejemplo dentro de `renderVals()`; tradúcelos a componentes React + Tailwind v4 usando los tokens de la sección 1.
2. **No copies datos de ejemplo.** Todo valor visible sale de la API. Si un dato no existe en el backend, se agrega al modelo (según la sección 7) o se muestra `—`. Nunca inventes cifras.
3. **Ignora las notas de diseño.** En los mockups, los textos azules pequeños que empiezan con «NUEVO —» son anotaciones para el cliente; no se renderizan.
4. **Idioma y formato.** Todo en español. Números con `toLocaleString("es-SV")`. Fechas cortas «19 sep», con hora «19 sep · 14:10», horas «09:40».
5. **Sin modales de confirmación para acciones que no destruyen nada** (verificar, empacar, enviar a fabricación, enviar a bodega, completar, iniciar, detener, reanudar, agregar a ruta, recoger). Se ejecutan directo y muestran un toast con botón **«Deshacer»** (6 s) cuando exista endpoint de reversa (sección 7). Solo las acciones destructivas (eliminar, cancelar pedido) piden confirmación.
6. **Cada fila muestra solo el botón de su siguiente paso.**
7. **Cuadros en línea en vez de modales encadenados** (componente `InlineResolveBox`). Solo un cuadro abierto a la vez por panel.
8. **Modales solo para decisiones reales**: «Enviar a bodega», «Nueva ruta», y los formularios de alta/edición que ya existen (nuevo pedido, nuevo artículo, nuevo lote, empleado, transacción, producto), restilizados.
9. **Pestaña y registro seleccionado en la URL** (`?tab=pedidos&id=<id>`) para que un recargo o un enlace desde otro módulo abra lo mismo. Parámetros usados entre módulos: `?tab=`, `?id=`, `?nuevo=1` (Fabricación abre «Nuevo lote»), `?bajoMinimo=1` (Inventario filtra bajo mínimo), `?ruta=` (Logística abre una ruta), `?filtro=sin-ruta` (Para despacho).
10. **No rompas otros módulos.** Si cambias un endpoint o un campo, busca todos sus usos (frontend y backend) y actualízalos en la misma fase.
11. **StatusPill es la única fuente de color de estados** (sección 1.4). Ningún componente arma su propio badge de estado.
12. **Accesibilidad mínima**: botones reales `<button>`, `aria-label` en botones de solo ícono, `title` en los íconos del menú, foco visible, contraste AA.
13. **Al terminar cada fase**: `npm run build` y `npm run lint` sin errores en el frontend; arranca el backend y verifica que no truene; actualiza la sección «Estado» de `docs/rediseno/AUDITORIA.md`; muestra un resumen de los archivos cambiados.
14. **No uses git.** No crees ramas, no hagas commits, push, merge, stash ni reset. El control de versiones lo maneja el usuario.

---

## 1. Sistema visual

### 1.1 Tipografía

- Fuente única: **Figtree** (Google Fonts, pesos 400, 500, 600, 700, 800). Reemplaza Inter.
- Cifras (montos, cantidades, IDs, fechas): `font-variant-numeric: tabular-nums` (utilidad `tabular-nums`). Nunca una fuente monoespaciada aparte.
- Escala:
  - Título de página (h1): 26px, 700, `letter-spacing: -0.025em`, color `ink`.
  - Subtítulo de página: 13px, 400, `muted`.
  - Título de tarjeta (h2): 15px, 700.
  - Título de detalle (ej. «LOT-0416», «Ruta 4 · Zona Norte»): 19–20px, 600–700, `-0.02em`.
  - Etiqueta de sección / encabezado de columna: 10.5px, 700, MAYÚSCULAS, `letter-spacing: 0.1em`, color `subtle`.
  - Texto de fila: 12.5–13.5px; nombre principal de fila 13.5px 600.
  - Valor de indicador grande: 20–25px 600 tabular; indicador en línea: 16px 600.
  - Texto auxiliar: 11–11.5px `muted`.

### 1.2 Tokens de color (declarar en `@theme` de `src/index.css`)

| Token | Hex | Uso |
| --- | --- | --- |
| `ink` | #16203A | Texto principal |
| `ink-2` | #4A5468 | Texto secundario, botones secundarios |
| `muted` | #6B7689 | Subtítulos, notas |
| `subtle` | #8A93A6 | Etiquetas en mayúsculas, ejes |
| `faint` | #A3ACBD | Deshabilitado |
| `canvas` | #F2F5FA | Fondo de la app |
| `surface` | #FFFFFF | Tarjetas |
| `surface-2` | #FAFBFD | Encabezados de tabla, tiles internos, pies de tarjeta |
| `line` | #E3E8F1 | Bordes de tarjeta y controles |
| `line-soft` | #F0F3F8 | Separadores de filas |
| `rail` | #24406F | Menú lateral |
| `rail-active` | #3A5B92 | Ícono activo del menú |
| `rail-icon` | #93A6C8 | Íconos inactivos |
| `primary` | #3168D4 | Botón principal, selección |
| `primary-hover` | #2A5BBC | Hover del principal |
| `primary-soft` | #E9F0FB | Botón suave, pestaña activa |
| `primary-soft-text` | #2C5CA8 | Texto sobre `primary-soft` |
| `select-bg` | #F3F7FD | Fila seleccionada, fondo de cuadro en línea |
| `select-bar` | #4A7FD4 | Barra izquierda de 5px de la fila seleccionada, borde punteado del cuadro en línea |
| `band` | #4A6FA5 | Franja de encabezado de tabla oscura (texto #E4ECF7) — solo tabla de paradas de Logística |
| `row-alert` | #FDF7F8 | Fila con bajo mínimo o ausencia |
| `row-new` | #F6FBF8 | Fila con ingreso reciente |

Reemplaza los `--color-brand-*` actuales por este sistema (mantén alias `brand-*` apuntando a `primary` mientras migras, y elimínalos en la Fase 11).

### 1.3 Tonos de estado

Cada tono tiene `tint` (fondo), `text` (texto) y `dot` (punto de 6–7px). En badges grandes (encabezado de detalle) se agrega borde `1px solid` del `dot` al 30 % de opacidad.

| Tono | tint | text | dot |
| --- | --- | --- | --- |
| gris | #EFF1F5 | #5C6579 | #8A93A6 |
| azul | #E9F0FB | #2C5CA8 | #4A7FD4 |
| ámbar | #FAF1DF | #96661A | #D9A441 |
| verde | #EAF4EE | #3B7D55 | #5AA872 |
| rosa | #F8EDEF | #9E4A5E | #C2697C |
| morado | #F1ECFA | #6A4FA3 | #8F74C9 |
| turquesa | #E8F3F7 | #2C7189 | #4E9CB5 |

### 1.4 Mapa estado → tono (por dominio)

`StatusPill` recibe `domain` además de `status`, porque la misma palabra cambia de color según el contexto (ej. «Pendiente»). Formas: pastilla de fila (22px de alto, radio 7px, 11px 600) y variante `size="lg"` para encabezados (26px, radio 8px, 12px, con borde). También existe la variante «texto con punto» (sin fondo, solo punto + texto del color `text`) que usan las listas maestro.

| Dominio | Estado → tono |
| --- | --- |
| `pedido` | Pendiente gris · Procesando azul · En Fabricación ámbar · Empacado morado · En Tránsito turquesa · Entregado verde |
| `pago` | Pendiente ámbar · Pagado verde · Reembolsado gris |
| `pedido-inventario` (estado macro en Inventario → Pedidos) | Sin verificar gris · Verificando azul · Listo para empacar verde · Esperando lote ámbar · Empacado morado |
| `linea-inventario` (producto dentro del pedido) | Por verificar gris · Verificado verde · Empacado morado · Existencia parcial ámbar · Sin existencia rosa · En fabricación azul |
| `lote` | Programado ámbar · En proceso azul · Detenido rosa · Completado verde · Por enviar ámbar · En bodega verde · Empacado morado |
| `pedido-fabricacion` (estado macro en Fabricación → Pedidos) | Programado ámbar · En proceso azul · En proceso · detenido rosa · Por empacar verde · Empacado morado |
| `ruta` | Pendiente gris · Recolectando azul · En tránsito turquesa · Completada verde · Demorada rosa |
| `parada` | Pendiente gris · Listo verde · Incompleto ámbar · En tránsito turquesa · Entregado verde |
| `despacho` (pedido en lista Para despacho) | Listo verde · Faltan N de M ámbar · Esperando gris |
| `stock` | Suficiente verde · Estable azul · Bajo mínimo rosa |
| `transaccion` | Pagado azul · Pendiente ámbar · Completado verde |
| `catalogo` | Destacado azul · Activo verde · Inactivo gris |
| `empleado` | Activo verde · Inactivo gris |
| `asistencia` | Completo verde · Con extra azul · Tarde ámbar · Ausente rosa |
| `vehiculo` | Disponible verde · En ruta turquesa |

Nota: el backend guarda el estado de lote como `"En Proceso"` (P mayúscula); se muestra «En proceso». Normaliza en el mapa.

### 1.5 Gráficos

Paleta categórica: #3D6FC9, #C4841C, #3C8F5E, #7F5FC7, #B85268 (en ese orden). Barras históricas atenuadas: #B9C6E0; barra destacada: #3D6FC9. Línea de referencia: `1px dashed #C3CBDA`. Grilla: #F0F3F8. Sin librerías de gráficos nuevas: barras y anillo con divs/SVG propios, como en los mockups.

### 1.6 Forma

- Tarjeta principal: radio 14px, borde 1px `line`, fondo `surface`, `overflow: hidden`.
- Tile interno (indicadores dentro de un detalle): radio 11–12px, borde 1px `line-soft`, fondo `surface-2`, padding 12px 14px.
- Botón principal: alto 38px (encabezado de página) / 34px (encabezado de detalle) / 28–30px (fila); radio 10 / 9 / 8px; 12.5–13px 600; fondo `primary`, texto blanco.
- Botón suave: fondo `primary-soft`, texto `primary-soft-text`. Botón secundario: fondo blanco, borde `line`, texto `ink-2`.
- Botones de estado de lote: **Iniciar** ámbar suave (fondo #FAF1DF, texto #96661A); **Detener** azul suave (fondo #E9F0FB, texto #2C5CA8); **Empacar** verde suave (fondo #EAF4EE, texto #3B7D55, **sin ícono**); **Reanudar** fondo blanco con borde.
- Chips de filtro: alto 26px, radio 8px, 11.5px 600. Activo: fondo `primary`, texto blanco. Inactivos: fondo `tint` y texto `text` del tono que representan (ej. «Detenidos · 1» rosa).
- Pastillas de selección (motorista/vehículo): alto 26–28px, radio completo, 11.5–12px 600. Seleccionada: fondo y borde `primary`, texto blanco. Disponible: fondo blanco, borde `line`, texto `ink-2`. Ocupada: fondo #F5F7FA, texto `faint`, borde `1px dashed #D7DEE9`, sufijo « · en ruta», no clicable.
- Modal: ancho 470px, radio 16px, padding 22px 24px, sombra `0 24px 60px rgba(22,32,58,.28)`, overlay `rgba(22,32,58,.32)`. Botón cerrar 30×30 radio 8 fondo `canvas`.
- Cuadro en línea (`InlineResolveBox`): borde `1px dashed #4A7FD4`, fondo #F3F7FD, radio 11px, padding 10–12px.

---

## 2. Layout de la aplicación

### 2.1 Menú lateral (riel)

- Ancho 68px, fondo `rail`, padding vertical 22px, íconos centrados en columna con gap 6px.
- Arriba: logotipo «IC» (36×36, radio 11, fondo `primary`, 13px 800 blanco), luego separador de 26×1px blanco al 16 %.
- Íconos de navegación 40×40, radio 12, ícono 19px trazo 1.8. Activo: fondo `rail-active`, ícono blanco. Inactivo: transparente, ícono `rail-icon`, hover blanco al 8 %.
- Orden: Dashboard, Fabricación, Finanzas, Pedidos, Logística, Inventario, Catálogo, Empleados (usa `NAV_ITEMS` de `src/lib/nav.jsx`). Abajo, separado: Configuración y un botón avatar con iniciales del usuario que abre un menú (nombre, cargo, «Cerrar sesión»).
- Cada ícono lleva `title` y `aria-label` con el nombre del módulo (tooltip al pasar el mouse).
- El botón «+ Nuevo Lote» sale del menú: vive en el encabezado de Fabricación. Mantén la lógica existente que abre el modal de nuevo lote al llegar desde ese acceso (ahora por `?nuevo=1`).
- Pantallas < 1024px: el riel se oculta y un botón de menú en el encabezado de página abre el cajón deslizable actual (misma navegación con etiquetas).

### 2.2 Encabezado de página

Se **elimina `TopBar`**. Cada página renderiza `<PageHeader title subtitle actions />`: título y subtítulo a la izquierda (de `NAV_ITEMS`/`getPageMeta`), acciones a la derecha alineadas abajo. Se eliminan la búsqueda global, la campana de notificaciones (no tenían datos) y «Descargar Reporte». El selector de rango de fechas (`DateRangePicker`) pasa a las acciones de Dashboard, Fabricación, Finanzas y los dos historiales, con estilo de control blanco 38px («Esta semana», «Abr – sep 2026»). Dashboard lleva además «Exportar» (reusa la función de reporte si existía; si no existía, omítelo).

### 2.3 Área de contenido

Padding 24px 28px, columna con gap 14px. Las pantallas maestro-detalle ocupan el alto de la ventana (`h-screen`) y cada panel hace scroll interno.

### 2.4 Pestañas de módulo

Control segmentado: caja blanca, borde `line`, radio 11px, padding 3px, gap 3px; cada pestaña 32px de alto, padding 0 13px, 12.5px 600; activa fondo `primary-soft` texto `primary-soft-text`; inactiva texto `muted`. Se ubica a la derecha de la fila de indicadores en línea (Fabricación, Inventario) o en el encabezado (Logística, Empleados).

### 2.5 Indicadores

- En línea (Fabricación, Inventario, Catálogo): cuadrito 8×8 radio 3 del color del indicador + etiqueta 11.5px 600 `muted` + valor 16px 600 tabular.
- En tarjeta (Dashboard, Finanzas): tarjeta 14px de radio, etiqueta en mayúsculas, valor 25px 600, nota 12px.

### 2.6 Maestro-detalle

Lista a la izquierda con ancho fijo (Pedidos 452px, Fabricación 424px, Logística 392px, Inventario → Pedidos 392px, Empleados 392px) y panel de detalle flexible. Fila seleccionada: fondo `select-bg` y barra izquierda de 5px `select-bar` (grid `5px 1fr`). Encabezado de lista: buscador (36px, fondo `surface-2`) y chips de filtro con conteo; los chips con conteo 0 se ocultan, excepto «Todos». Encabezado del detalle: fondo `surface-2`, borde inferior `line-soft`, padding 16px 20px.

---

## 3. Componentes compartidos (`src/components/ui/`)

Crear o reescribir: `PageHeader`, `Tabs` (segmentado), `KpiInline`, `KpiCard` (restilizado), `StatTile`, `StatusPill` (con `domain`, `size`, `variant="dot"`), `FilterChips`, `SearchInput`, `MasterDetail` (`ListPanel`, `DetailPanel`, `ListRow` seleccionable), `Stepper` (N pasos con nombre y fecha), `MiniStepper` (segmentos), `InlineResolveBox`, `PillSelector` (seleccionada/disponible/ocupada), `RadioCardList` (opciones tipo tarjeta con radio, título, detalle y etiqueta opcional — usado en «Enviar a bodega»), `DisclosureChevron` (flecha hacia abajo de 14px, trazo 2.3, color #C3CBDA, gira 180° al abrir con transición de 150ms), `StockMeter` (barra 6px + etiqueta), `ProgressBar`, `BulkBar`, `EmptyState`, `Modal` (restilizado), `DataTable` (encabezado en mayúsculas sobre `surface-2`, filas 42–46px separadas por `line-soft`), `toastUndo(message, onUndo)` sobre `react-hot-toast` (toast blanco con texto y botón «Deshacer», 6 s).

Las filas que se expanden (productos en Inventario → Pedidos, lotes en Fabricación → Pedidos) llevan `DisclosureChevron` en una columna final de 18px y toda la fila es clicable para abrir/cerrar.

---

## 4. Flujo de negocio completo (nuevo)

1. **Pedidos.** Al crearse un pedido pasa solo a Inventario (`sentToInventoryAt`), sin botón «Solicitar». Configurable con la constante `AUTO_SEND_TO_INVENTORY_ON` = `"create"` (por defecto) o `"paid"`.
2. **Inventario → Pedidos.** Cada producto del pedido llega con su bodega sugerida:
   - Con existencia completa → «Verificar» (descuenta stock) → «Empacar» (queda para recoger en **Almacén**).
   - Con existencia parcial → «Resolver faltante»: «Tomar X y fabricar Y» (la línea se divide) o «Fabricar las N».
   - Sin existencia → «Enviar a fabricación»: crea el lote de categoría «Pedido» en estado Programado en el mismo clic.
3. **Fabricación → Pedidos.** Lote Programado → «Iniciar» → En proceso («Detener»/«Reanudar» si hace falta) → cuadro «Completar» (cantidad) → Completado → «Empacar» (por lote o «Empacar completados») → Empacado, queda para recoger en **Fabricación**.
4. **Fabricación → Lotes de fabricación** (lotes de stock, no de pedido). En proceso → Completado («Por enviar») → «Enviar a bodega» (modal con bodega) → «En bodega»; las unidades aparecen al instante en Inventario → Producto terminado con marca de ingreso reciente.
5. **Logística.** Se arma una ruta («Armar ruta»: zona, motorista, vehículo). Los pedidos con algo empacado se suman con «+ Ruta N». La ruta recoge primero (Almacén y/o Fabricación, «Confirmar recogido»), luego «Salir a ruta», y entrega parada por parada («Entregado»). Cuando todas las paradas están entregadas, la ruta queda Completada.
6. El pedido avanza solo por sus estados: Pendiente → Procesando → En Fabricación (si alguna línea se fabrica) → Empacado (todas las líneas empacadas) → En Tránsito (ruta salió) → Entregado (parada entregada). Cada cambio se guarda en `statusHistory`.

---

## 5. Especificación por módulo

### 5.1 Pedidos — mockup `V3-Maestro.dc.html`

- Maestro-detalle. Lista 452px: buscador «Buscar pedido», chips Todos · N, Pendientes · N (status Pendiente), En ruta · N (En Tránsito), Sin pago · N (paymentStatus Pendiente). Fila: número de pedido (tabular), estado (`pedido`, variante punto), cliente, total.
- **Sin selector Lista/Tarjetas/Tablero** (eran variantes de exploración): solo la vista de lista.
- Encabezado: título «Pedidos», subtítulo «N activos · selecciona un pedido para ver su ficha completa», botón «Nuevo pedido» (abre el modal de alta existente, restilizado).
- Ficha: número, badge de estado (`pedido`, lg), badge de pago (`pago`), etiqueta «Pasó solo a Inventario» cuando `sentToInventoryAt` existe, botón «Editar». Recorrido de 6 tramos (`Stepper`): Pendiente, Procesando, En Fabricación, Empacado, En Tránsito, Entregado, cada uno con su fecha tomada de `statusHistory` (tramo sin fecha = pendiente; «En Fabricación» se muestra como «omitido» si el pedido pasó de Procesando a Empacado sin fabricar). Bloques: Cliente (nombre, correo, teléfono), Entrega (dirección, «Zona · Ruta N» o «sin asignar»), Fechas (Solicitado, Prometido si existe el campo, Última acción = último registro de `statusHistory`). Tabla de productos: Producto (con muestra de color), Color, Cant., Unitario, Subtotal, y «Total del pedido».
- Se elimina el modal «Solicitar a inventario» y su botón.

### 5.2 Inventario

Pestañas: **Producto terminado** (por defecto) · **Materia prima** · **Pedidos**. «Lotes reportados» se elimina en la Fase 5 (sección 5.4).

**Producto terminado** — mockup `M5-Inventario.dc.html`.
- Encabezado: «Inventario» / «Materia prima y stock de productos terminados»; acciones «Reportar entrada» (solo si ya existe una función de entrada manual de stock; si no, omitir) y «Nuevo artículo».
- Indicadores en línea: Artículos, Unidades, Bajo mínimo.
- Tarjeta con barra de filtros: buscador «Buscar artículo o color», «Bodega: todas», «Color: todos», chip rosa «Solo bajo mínimo · N» (conmutador).
- Tabla: Artículo · Color (muestra) · Tipo · Existencia (derecha) · Bodega · Nivel de stock (`StockMeter`) · Acción (editar ícono + «…»). Pie: «N de M artículos · X unidades en total» y paginación.
- Nivel de stock, 3 niveles usando los umbrales existentes `STOCK_THRESHOLDS` (T): Bajo mínimo si `stock < T`; Estable si `T ≤ stock < 3T`; Suficiente si `stock ≥ 3T`. Medidor: `min(100, stock / (4T) × 100)` %. Fila con Bajo mínimo fondo `row-alert`.
- Ingreso reciente: si el artículo tiene `lastInbound` con fecha de hoy o ayer, fila con fondo `row-new` y debajo del nombre una línea verde con flecha hacia arriba: «+3,050 de Fabricación · LOT-0416 · hoy» (o «ayer»).

**Materia prima** — mockup `M5b-MateriaPrima.dc.html`. Misma tabla sin columna Color, filtro «Tipo: todos», chip «Solo bajo mínimo · N», indicadores Artículos y Bajo mínimo. Existencia con su unidad («820 kg», «300 rollos»).

**Pedidos** — mockup `R1-InventarioPedidos.dc.html`. Ver 5.3.

### 5.3 Inventario → Pedidos

- Encabezado de pestaña: subtítulo «Pedidos — llegan solos, se verifican de una vez y se empacan sin confirmación».
- **Lista** (392px): selector «Por preparar · N» / «Despachados · N» con nota «salen al recogerse todo». Por preparar = pedidos enviados a Inventario cuyo status no es En Tránsito ni Entregado. Despachados = En Tránsito o Entregado (últimos 30 días).
- Fila de pedido: casilla de selección (columna de 30px, casilla con `padding-left: 11px`), número, estado macro (`pedido-inventario`, variante punto), cliente, avance («2 de 6 listos», «1 de 2 · L-4828 en proceso»). Listos = líneas verificadas o empacadas.
- Estado macro: Empacado si todas las líneas están empacadas; Esperando lote si todas las líneas pendientes están en fabricación; Listo para empacar si todas las pendientes están verificadas; Sin verificar si ninguna línea fue procesada; si no, Verificando.
- **Selección múltiple**: al marcar pedidos aparece `BulkBar` arriba de la lista: ícono, «N seleccionados», botón «Verificar seleccionados», «Cancelar», y debajo (alineado con el texto) la vista previa: «X de Y productos tienen existencia completa y se verificarán · Z quedarán pendientes por revisar». Verifica en todas las líneas con existencia completa usando su bodega sugerida.
- **Detalle**: número, estado macro (lg), «Cliente · llegó solo el 19 sep»; a la derecha «Empacar verificados · N» (solo si N > 0). Fila de conteos: «6 productos · 1 empacado · 1 verificado · 2 por verificar · 1 parcial · 1 en fabricación» (omite los 0). Cuadro de sugerencia (si aplica): «N productos tienen existencia completa en una bodega» + lista «Producto → Bodega» + botón «Verificar todo · N».
- **Tabla de productos**: columnas `minmax(0,1fr) 44px 138px 124px 178px 18px` = Producto · Cant. · Existencia · Estado · Acción · flecha. Sin la palabra «sugerida».
  - Existencia muestra: «Bodega A · 400 disp.» (por verificar), «Bodega A · tomado» (verificado/empacado), «Bodega B · solo 25» (parcial), «Sin existencia».
  - Acción por estado:
    | Estado | Acción |
    | --- | --- |
    | Por verificar | Botón azul «Verificar»: abre `InlineResolveBox` bajo la fila con las bodegas que tienen stock (radio), la sugerida preseleccionada, botón «Verificar en {bodega}» y «Cancelar» |
    | Verificado | Botón verde suave «Empacar» (directo + Deshacer) |
    | Empacado | Texto «Esperando motorista»; si ya está en una ruta: «Ruta N · {motorista}» |
    | Existencia parcial | Botón ámbar «Resolver faltante»: cuadro con «Solo hay 25 en Bodega B y ninguna otra tiene más.» y botones «Tomar 25 y fabricar 35» (principal) y «Fabricar las 60» |
    | Sin existencia | Botón «Enviar a fabricación» (crea el lote Programado) |
    | En fabricación | Texto del lote: «Lote L-4830 · En proceso» con el estado real del lote |
  - Al expandir con la flecha: bodegas con existencia de ese producto/color (bodega y disponible) o, en líneas en fabricación, el lote con meta, producido y estado.
- Bodega sugerida: la bodega con stock ≥ cantidad para ese producto y color; si hay varias, la de mayor stock. Si ninguna alcanza, pero alguna tiene algo: «Existencia parcial» con la de mayor stock.
- Debajo de la tabla, solo si el pedido tiene líneas empacadas: leyenda «Después de empacar, la fila sigue al pedido en Logística» con la progresión Empacado «Esperando motorista» → Empacado «Ruta 4 · Luis García» → En tránsito «Recogido 09:40» → Entregado «Entregado 19 sep».
- Se elimina «Eliminar de la lista» (el pedido ya no se «solicita»).
- **Corrección**: el producto nunca se muestra «Entregado» solo por tener motorista asignado; usa el estado del pedido y las fechas de recogida/entrega.

### 5.4 Fabricación

Pestañas: **Lotes de fabricación** · **Producción diaria** · **Pedidos**. Encabezado: «Fabricación» / «Control de líneas de producción y calidad», acciones: selector de rango («Esta semana») y «Nuevo lote». Indicadores en línea: Producción (unidades producidas en el rango), En proceso, Detenidos.

**Lotes de fabricación** (lotes que no son de categoría «Pedido») — mockups `M2-Fabricacion.dc.html` y `M2c-EnviarBodega.dc.html`.
- Lista 424px: buscador «Buscar lote, producto o color», chips Todos · N, En proceso · N, Por enviar · N, Detenidos · N. Fila 58px: «LOT-0416 · Línea 3», estado (`lote`, variante punto), muestra de color, producto, producido.
- Estados de lote de stock: Programado → En proceso → (Detenido) → Completado. Visualmente, un Completado sin enviar se muestra **«Por enviar»** y uno enviado **«En bodega»**.
- Detalle — encabezado: número, badge («Completado · por enviar», «En proceso», «Detenido», «En bodega»), «Producto · Línea · terminó hoy 14:10» (o «inició 06:00»). Acción principal según estado: Programado «Iniciar»; En proceso «Detener» + «Completar» (abre cuadro en línea con la cantidad producida ya llena con la meta y «Confirmar»); Detenido «Reanudar»; Por enviar **«Enviar a bodega»** (principal, ícono de bodega); En bodega texto «En {bodega} · {fecha}». Botón «…» con Editar y Eliminar.
- «Avance del lote»: «3,050 de 3,000 unidades · 102 %» y barra de 10px (verde si ≥ 100 %, azul si menos). Mientras está en proceso: «En proceso desde 06:00 · meta 3,000» sin barra.
- Cuatro tiles: **Meta** («unidades del lote»), **Producido** («102 % de la meta»; «—» si no se ha completado), **vs. lote anterior** (diferencia % contra el lote completado anterior de la misma línea; nota «−550 u. vs. LOT-0412»; ámbar si es negativo, verde si es positivo, «—» si no hay anterior), **Promedio de la línea** (promedio de producido de los últimos 6 lotes completados de la línea; nota «últimos 6 lotes · Línea 3»).
- Gráfica **«Últimos lotes de {línea}»** (nota derecha «Meta 3,000 u. por lote»): barras de los últimos 6 lotes completados de esa línea en orden cronológico, valor encima, fecha debajo («02 sep»; el actual «Hoy» si es de hoy), actual en #3D6FC9 y 700, los demás #B9C6E0; línea punteada horizontal a la altura de la meta del lote actual con etiqueta «Meta». Se elimina «Unidades por hora», «Defectuoso» y «Rendimiento».
- «Ficha del lote»: Producto, Color, Línea, Operario, Inicio, Fin (con hora si existe `startedAt`/`completedAt`; si no, solo fecha).
- **Modal «Enviar a bodega»** (`M2c`): título, línea con muestra de color «Pajilla Verde · LOT-0416 · 3,050 unidades», etiqueta «Bodega de destino», `RadioCardList` con cada bodega: nombre y detalle («Ya tiene 6,560 · quedarían 9,610 unidades» o «Sin este artículo · entraría como nuevo»); preseleccionada la que ya tiene el artículo (etiqueta «Ya está aquí»; si varias, la de más stock); texto «Las unidades aparecen de una vez en Inventario → Producto terminado, en la bodega elegida. El lote queda aquí marcado «En bodega».»; botones «Cancelar» y «Enviar a {bodega}». Al confirmar: toast con Deshacer.

**Producción diaria** — mockup `M2b-ProduccionDiaria.dc.html`. Tabla con ID, Fecha, Producto, Color (muestra + nombre), Acciones («Programar» y las acciones que ya existan). Indicadores Lotes hoy, Esta semana. Mantiene su lógica actual.

**Pedidos** — mockup `R4-PedidosMasterDetail.dc.html`. Fusiona «Por fabricar» y «Fabricación de pedidos».
- Lista: chips Todos, En proceso, Por empacar, Detenidos. Fila: número, estado macro (`pedido-fabricacion`), cliente, «N productos», `MiniStepper` de 4 segmentos.
- Estado macro del pedido (sobre sus lotes): Programado si todos Programado; Empacado si todos empacados; Por empacar si todos completados o empacados y alguno sin empacar; si no, En proceso («En proceso · detenido» si algún lote está Detenido).
- Detalle: número, badge, «Cliente · N productos · llegó de Inventario el 15 sep», enlace «Ver productos completos» (abre el pedido en Pedidos con `?id=`). `Stepper` Programado → En proceso → Completado → Empacado con fechas (primer `startedAt`, último `completedAt`, último empaque).
- Alerta de detención (si algún lote está Detenido): «1 lote detenido por {motivo}» con botón «Reanudar».
- «Lotes de este pedido» + resumen «5 lotes · 1 completado · 1 empacado» + botón **«Empacar completados · N»** (solo si N > 0; empaca todos los Completados; un toast con Deshacer).
- Fila de lote: número, producto · color, cantidad «40 u», estado, acción, flecha:
  | Estado | Acción |
  | --- | --- |
  | Programado | «Iniciar» (ámbar suave). Si el lote no tiene línea u operario, abre un cuadro en línea para elegirlos (selects), luego inicia |
  | En proceso | «Detener» (azul suave) y, debajo de la fila, el cuadro **«Completar L-4823»**: «Producidas [30] meta 30», «Confirmar», «Cancelar» |
  | Detenido | «Reanudar» |
  | Completado | «Empacar» (verde suave, sin ícono) |
  | Empacado | Texto «En recolección · Fabricación» (o «Recogido 09:40» cuando Logística confirma) |
- «Detener» abre un cuadro en línea con «Motivo (opcional)» y «Detener».
- Al expandir un lote: meta, producido, línea, operario, inicio, fin y motivo de detención.
- Lo empacado aparece en Logística → Para despacho como recogida en «Fabricación».

### 5.5 Logística

Pestañas: **En tránsito** · **Para despacho**. Botón principal **«Armar ruta»** en el encabezado de ambas. Subtítulo «Asignación de motoristas, vehículos y seguimiento de entregas».

**En tránsito** — mockup `M4-Logistica.dc.html`.
- Lista 392px «Rutas de hoy» (nota «19 sep · N rutas»). Fila: «Ruta 2 · Zona Poniente», estado (`ruta`), avatar con iniciales del motorista, nombre (o «Sin motorista asignado»), placa, barra de avance y «3/6» paradas entregadas. Pie: «N pedidos sin ruta asignada» con enlace «Asignar» que abre Para despacho con el filtro «Sin ruta».
- Detalle: «Ruta 2 · Zona Poniente», badge, acción «Reasignar» (solo antes de salir: muestra los selectores de motorista y vehículo). Tarjeta del motorista (avatar, nombre, «Motorista · teléfono»). Tiles: **Paradas** «3 / 6» («la mitad de la ruta»), **Entregado** «$2,105» («de $4,320 en el camión»), **Salida** «07:45» («hace 2 h 10 min»; «—» si no ha salido).
- «Paradas de la ruta» + nota «Vehículo P-4471 · salió 07:45». Tabla con franja `band`: # · Pedido · Cliente · Dirección · Hora (hora de entrega o «—») · Estado (`parada`) · Acción («Entregado» en la siguiente parada pendiente cuando la ruta está En tránsito). Número en círculo: verde si entregada, azul relleno si es la actual, gris si pendiente.

**Para despacho** — mockup `M4b-ParaDespacho.dc.html`.
- Subtítulo «Para despacho — una ruta, varios pedidos: primero se recoge, después se entrega».
- Lista «Pedidos para despacho» (nota «19 sep · N pedidos»), chips Todos, Sin ruta, Incompletos. Incluye pedidos con al menos una línea empacada que no han salido. Fila: número, estado de despacho («Listo · 5 de 5» verde, «Faltan 4 de 5» ámbar, «Esperando · 1 de 2» gris), cliente, municipio/zona, chips de recogida («Almacén», «Fabricación» con ícono), y a la derecha: la ruta asignada («Ruta 4» o «Ruta 3 · J. Menjívar») o el botón **«+ Ruta N»** (N = la ruta abierta en el panel derecho; si no hay ruta abierta, el botón dice «Armar ruta» y abre el modal). Fila con lote en proceso: nota en cursiva «lote L-4828 en proceso».
- Panel de ruta: «Ruta 4 · Zona Norte», badge, resumen «3 pedidos · 2 recogidas · 3 entregas», botón **«Salir a ruta»** (deshabilitado con nota «falta 1 recogida», «falta motorista» o «falta vehículo»), «…» (Eliminar ruta si está vacía y no salió).
- Bloque Motorista / Vehículo con `PillSelector` (ocupados bloqueados «· en ruta»). Cambiar una pastilla guarda al instante.
- Línea de tiempo vertical: **«1 · Recoger»** con una parada por ubicación requerida (Almacén, Fabricación): «8 productos · PED-1031 (5) y PED-1035 (3)», botón «Confirmar recogido» o «Recogido 09:40» con check. Aviso ámbar para pedidos incompletos: «A PED-1040 le faltan 4 de 5 productos: 1 completado sin empacar, 1 en proceso, 1 detenido y 1 programado. Si sale hoy, habrá que volver a Fabricación.» con «Quitar de la ruta» y «Llevar lo que hay». **«2 · Entregar»**: paradas en orden (cliente, «PED · dirección», estado `parada`).
- «Llevar lo que hay»: el pedido se queda en la ruta; solo se recoge y entrega lo empacado. Al entregarse, las líneas entregadas quedan con `deliveredAt`; el pedido pasa a Entregado solo si todas sus líneas se entregaron. Si no, vuelve a Para despacho con una etiqueta «Entrega parcial» para una segunda ruta.

**Modal «Nueva ruta»** — mockup `M4c-ArmarRuta.dc.html`.
- Título «Nueva ruta», subtítulo «Se creará como **Ruta N** · número asignado automáticamente» (N = siguiente número del día).
- «Zona» (input obligatorio, ej. «Zona Norte»), «Motorista» (`PillSelector` de empleados del área Logística activos), «Vehículo» (`PillSelector` de placas de Configuración). Motorista y vehículo son opcionales al crear (se pueden elegir después en el panel), pero son obligatorios para «Salir a ruta».
- Texto: «Los pedidos se agregan después, uno por uno, desde Para despacho con el botón «+ Ruta N» en cada pedido listo.»
- Botones «Cancelar» y «Crear Ruta N». Al crear, abre la pestaña Para despacho con esa ruta en el panel derecho.

### 5.6 Dashboard — mockup `M1-Dashboard.dc.html`

Encabezado con rango de fechas y «Exportar». Tres indicadores en tarjeta con ícono: Producción total (unidades), Ingresos (con variación % contra el rango anterior si se puede calcular; si no, sin nota), Pedidos en curso («N listos» = Empacados). Tarjeta «Historial de lotes» con «Ver todo», buscador, filtros Producto y Línea, tabla Lote · Fecha · Producto · Color · Línea · Producido · Estado (`lote`), pie «N de M lotes en el rango» y «Ver historial completo» (ruta existente `/historial-lotes`). «Producción por producto» (anillo con la paleta categórica y leyenda, total al centro). «Alertas · N activas»: cada alerta es un enlace al registro que la origina (lote detenido → Fabricación con `?id=`; bajo mínimo → Inventario con filtro; pedido incompleto en ruta → Logística).

### 5.7 Finanzas — mockup `M3-Finanzas.dc.html`

Encabezado con rango y «Nueva transacción». Cuatro indicadores: Ingresos, Gastos, Rentabilidad neta (verde si positiva, rosa si negativa), Por cobrar / pagar (ámbar, nota «N pedidos»). Tarjeta «Ingresos y gastos por mes» (dólares, últimos seis meses, barras agrupadas #3D6FC9 / #C4841C, eje $, mes actual en negrita, recuadro flotante del mes seleccionado con ingresos, gastos y neto; al hacer clic en un mes se cambia el recuadro). Tabla «Transacciones»: buscador «Concepto o referencia», «Tipo: todos», «Ver historial» → `/historial-transacciones`; columnas Referencia · Fecha · Concepto (+ chip del pedido vinculado) · Categoría · Monto (verde «+», rosa «−») · Estado (`transaccion`).

### 5.8 Catálogo — mockup `M6-Catalogo.dc.html`

Encabezado: «Ver tienda pública» (enlace a la URL pública si está configurada) y «Nuevo producto». Indicadores Productos, Activos, Destacados. Pestañas por categoría con conteo (Todas y cada categoría existente). Cuadrícula de 4 columnas: imagen del producto (o ilustración/placeholder con el color de fondo suave), chip de categoría, estado (`catalogo`: Destacado si `featured`, Activo, Inactivo), nombre, «Mínimo X · stock Y», precio y `compareAtPrice` tachado si existe, muestras de colores + «N colores», botones «Editar», subir imagen (ícono) y «…».

### 5.9 Empleados — mockups `M7-Empleados.dc.html` y `M7b-Asistencia.dc.html`

Pestañas **Personal** · **Asistencia** (no se agrega «Planilla»: no existe en el sistema). Botón principal «Nuevo empleado» (Personal) o «Registrar marcación» (Asistencia).
- Personal: maestro-detalle; lista con buscador y chips por área (Todos y las áreas con empleados: Fabricación, Logística, etc.); ficha con avatar, nombre, puesto · área, documento si existe, estado (`empleado`: Activo/Inactivo según `isActive`), «Registrar asistencia», «Editar», tabla de asistencia del mes (Fecha, Entrada, Salida, Horas, Extra, Estado `asistencia`) con anchos que muestren fecha y horas completas, y «Datos del empleado».
- Asistencia: línea de tiempo agrupada por día («Viernes 19 de septiembre · N marcaciones»); por empleado una barra sobre una franja 06:00–18:00 con marcas 6:00, 9:00, 12:00, 15:00, 18:00: tramo azul = jornada dentro de 8 h, tramo ámbar = hora extra, entrada y salida rotuladas; columna Horas; día sin marcación = «Ausente» rosa. Leyenda «Jornada» / «Hora extra». Filtro «Mes».

### 5.10 Configuración — mockup `M8-Configuracion.dc.html`

Menú de secciones a la izquierda con **solo las secciones que existen**: Empresa, Bodegas (con conteo), Vehículos (con conteo). Formulario a la derecha. Barra superior «Cambios sin guardar» con «Descartar» y «Guardar cambios» cuando hay cambios en Empresa. Bodegas y Vehículos: listas con edición en línea y una fila «Agregar» en línea (sin modal de un solo campo). Vehículos muestra estado `vehiculo`: «En ruta» si está en una ruta activa, si no «Disponible». Subtítulos: Bodegas «Destinos disponibles para enviar lotes y verificar pedidos»; Vehículos «Flota disponible para armar rutas».

### 5.11 Historiales

`/historial-lotes` y `/historial-transacciones` adoptan `PageHeader`, filtros y `DataTable` con el mismo estilo.

---

## 6. Datos de referencia de los mockups

Los mockups usan datos ficticios (clientes, placas, lotes). Úsalos solo para entender formato y longitud de textos.

---

## 7. Cambios de modelo y API (backend)

Adapta nombres a las convenciones reales del backend (revisa `docs/rediseno/AUDITORIA.md`). Todo endpoint nuevo valida estado previo y devuelve el documento actualizado.

### 7.1 Order
- `sentToInventoryAt: Date` — se llena al crear (o al marcar Pagado según `AUTO_SEND_TO_INVENTORY_ON`) reutilizando la lógica de `PATCH /orders/:id/request-inventory` (que queda idempotente por compatibilidad).
- `statusHistory: [{ status, at }]` — se agrega un registro en cada cambio de `status` (incluida la creación). Migración: pedidos existentes reciben un registro con su estado actual y `updatedAt`.
- Ítems: `verifiedWarehouse` (si no existe ya), `packedAt`, `deliveredAt`, `splitFrom` (índice o id de la línea original cuando se divide).
- `delivery.route: ObjectId(Route)`; `delivery.deliveredAt`. Se mantienen `delivery.driver`, `delivery.vehicle`, `delivery.pickupWarehouseAt`, `delivery.pickupFactoryAt`, `delivery.dispatchStatus` sincronizados desde la ruta para compatibilidad.
- Endpoints nuevos:
  - `PATCH /orders/:id/items/:index/unverify` — devuelve el stock a la bodega y quita la verificación (Deshacer). Solo si no está empacado.
  - `PATCH /orders/:id/items/:index/unpack` y `.../unpack-manufactured` — Deshacer empaque; solo si no se ha recogido.
  - `PATCH /orders/:id/items/:index/split-partial` `{ warehouse, quantity }` — divide la línea: la original queda con `quantity` tomada y verificada en esa bodega (descuenta stock); se agrega una línea nueva con el resto, mismo producto/color/precio unitario, `splitFrom`, enviada a fabricación **con su lote creado** (Programado, meta = resto). El total del pedido no cambia.
  - `PATCH /orders/:id/verify-bulk` `{ items: [{ index, warehouse }] }` — verifica varias líneas en una transacción (para «Verificar todo» y «Verificar seleccionados»; el segundo recibe varios pedidos: `POST /orders/verify-bulk` `{ orders: [{ id, items }] }`).
- `PATCH /orders/:id/items/:index/send-manufacturing` ahora **también crea el lote** (lo que hoy hace `/manufacture`). `/manufacture` queda como alias.
- Se elimina el uso de `DELETE /orders/:id/request-inventory` en la UI.

### 7.2 ProductionBatch
- Estados sin cambios: `Programado`, `En Proceso`, `Detenido`, `Completado`.
- Campos: `startedAt`, `completedAt`, `stoppedAt`, `stopReason`, `sentToWarehouseAt`, `destinationWarehouse`, `packedAt` (lotes de pedido).
- Endpoints:
  - `PATCH /productionBatches/:id/start` `{ productionLine?, operator? }` — Programado → En Proceso, `startedAt`.
  - `PATCH /productionBatches/:id/stop` `{ reason? }` — En Proceso → Detenido.
  - `PATCH /productionBatches/:id/resume` — Detenido → En Proceso.
  - `PATCH /productionBatches/:id/complete` `{ producedQuantity }` — En Proceso → Completado, `completedAt`. `PATCH .../reopen` — Deshacer (Completado → En Proceso) si no se ha enviado ni empacado.
  - `PATCH /productionBatches/:id/send-to-warehouse` `{ warehouse }` — solo lotes que no son de pedido y están Completados sin enviar: crea o incrementa el producto terminado (mismo artículo, color y bodega), guarda `lastInbound` en ese artículo, marca el lote enviado. `PATCH .../undo-send` — revierte si el stock sigue disponible.
  - `POST /productionBatches/pack-completed` `{ batchIds }` — empaca varios lotes de pedido Completados (todo o nada) para «Empacar completados».
- Se retira el flujo «Reportar» (`ReportBatchModal`, `UndoReportModal`, `PATCH /inventory/:id/send`, `DELETE /inventory/:id/report`). **Migración**: los artículos reportados pendientes (`sentToWarehouse` falso) se envían a su bodega ya elegida y sus lotes quedan «En bodega».

### 7.3 Inventory
- `lastInbound: { quantity, batchNumber, at }`.

### 7.4 Route (modelo nuevo)
- `number` (secuencial por día desde 1), `date` (día), `zone`, `driver` (Employee, opcional), `vehicle` (placa, opcional), `orders: [ObjectId]` en orden de entrega, `status`: `Pendiente` | `Recolectando` | `En tránsito` | `Completada`, `delayed: Boolean`, `departedAt`, `completedAt`, `pickups: { almacen: { confirmedAt }, fabricacion: { confirmedAt } }`.
- Estado: Pendiente al crear; Recolectando cuando tiene motorista, vehículo y al menos un pedido; En tránsito al salir; Completada cuando todas las paradas están entregadas.
- Recogidas requeridas: se derivan de los pedidos (Almacén si alguna línea empacada tiene `packedLocation` Almacén; Fabricación si Fabricación).
- Endpoints: `GET /routes?date=YYYY-MM-DD` (con pedidos, motorista poblados), `POST /routes` `{ zone, driver?, vehicle? }`, `PATCH /routes/:id` `{ zone?, driver?, vehicle? }`, `DELETE /routes/:id` (solo vacía y sin salir), `POST /routes/:id/orders` `{ orderId }`, `DELETE /routes/:id/orders/:orderId`, `PATCH /routes/:id/pickup` `{ location: "Almacén" | "Fabricación" }` (marca la recogida en la ruta y en cada pedido), `PATCH /routes/:id/depart` (valida motorista, vehículo, ≥ 1 pedido y recogidas confirmadas; pedidos → En Tránsito, `dispatchStatus` «A tiempo»), `PATCH /routes/:id/orders/:orderId/deliver` (líneas recogidas → `deliveredAt`; pedido → Entregado si todas las líneas se entregaron; si no, sale de la ruta y vuelve a Para despacho con entrega parcial). `PATCH /routes/:id/orders/:orderId/undeliver` (Deshacer, solo el mismo día; si la ruta estaba Completada vuelve a En tránsito). `GET /routes/availability?date=` (motoristas y vehículos con `busy` y la ruta en que están).
- Motoristas/vehículos ocupados = los asignados a rutas del día que no están Completadas.
- Los endpoints viejos `PATCH /orders/:id/delivery` y `/delivery/pickup` quedan por compatibilidad pero la UI ya no los usa.

---

## 8. Textos exactos clave

Botones: «Nuevo pedido», «Editar», «Verificar», «Verificar todo · N», «Verificar seleccionados», «Empacar», «Empacar verificados · N», «Resolver faltante», «Tomar X y fabricar Y», «Fabricar las N», «Enviar a fabricación», «Iniciar», «Detener», «Reanudar», «Confirmar», «Cancelar», «Empacar completados · N», «Enviar a bodega», «Enviar a {bodega}», «Armar ruta», «Crear Ruta N», «+ Ruta N», «Confirmar recogido», «Salir a ruta», «Quitar de la ruta», «Llevar lo que hay», «Entregado», «Reasignar», «Deshacer».

---

## 9. Decisiones que prevalecen sobre los mockups (cabos sueltos resueltos)

1. **Completar y empacar son dos pasos** (el tablero `F1-FlujoPedido` todavía dice «Completar y empacar» en un botón): Completar deja el lote en Completado; Empacar es aparte, por lote o con «Empacar completados».
2. **Tono de «Por verificar»** es gris (como en `R1`), no azul.
3. **«Sin existencia»** es un estado propio de la línea en Inventario (rosa) con el botón «Enviar a fabricación»; el mockup solo mostraba la línea ya en fabricación.
4. **Unidades por hora, Defectuoso y Rendimiento no existen**: se reemplazan por «Últimos lotes de la línea», «vs. lote anterior» y «Promedio de la línea».
5. **Hora de inicio y fin del lote**: se agregan `startedAt`/`completedAt`; lotes viejos muestran solo fecha.
6. **Iniciar un lote sin línea u operario** pide ambos en un cuadro en línea (los lotes creados desde Inventario no los traen).
7. **Motivo de detención**: campo `stopReason` opcional al presionar Detener; alimenta la alerta de Fabricación → Pedidos y el Dashboard.
8. **Logística «Ver seguimiento» y «Retraso» se eliminan** (no hay datos de GPS ni hora prevista). «Retraso» se reemplaza por «Salida». «Reasignar» solo antes de salir.
9. **«Ruta 0 · Retornos» se elimina**; las rutas se numeran por día desde 1.
10. **Motorista y vehículo opcionales al crear la ruta** (así se explica la «Ruta 4 · Sin motorista asignado» del mockup de En tránsito), obligatorios para salir.
11. **«+ Ruta N»** siempre apunta a la ruta abierta en el panel; sin ruta abierta el botón es «Armar ruta».
12. **«Llevar lo que hay»** entrega parcial: el pedido vuelve a Para despacho con lo que falte.
13. **TopBar se elimina** (búsqueda global y campana no tenían función); el rango de fechas pasa a los encabezados.
14. **Selector Lista/Tarjetas/Tablero de Pedidos no se implementa.**
15. **Empleados sin pestaña «Planilla»**; áreas reales (Logística, no «Reparto»); estado Activo/Inactivo, no Vacaciones/Incapacidad.
16. **Configuración solo con Empresa, Bodegas y Vehículos**; «Líneas de producción», «Usuarios y permisos» y «Mi cuenta» del mockup no existen en el sistema.
17. **Vehículo «Taller»** no se implementa (no hay campo).
18. **«Reportar entrada»** en Inventario solo si ya existe esa función.
19. **Nivel de stock de 3 niveles** con los umbrales actuales (sección 5.2).
20. **Pedido pasa a Inventario al crearse** por defecto, configurable a «al pagarse».
21. **La leyenda «Después de empacar…»** se muestra solo si el pedido tiene líneas empacadas.
22. **Filas con flecha**: el contenido al expandir está definido en 5.3 y 5.4 (los mockups no lo dibujaban).
