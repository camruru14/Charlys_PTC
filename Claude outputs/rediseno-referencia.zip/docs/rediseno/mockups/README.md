# Mockups del rediseño

Cada archivo `.dc.html` es un tablero de 1440 × 880 px (el flujo mide 1440 × 1780). No se abren solos en el navegador: dependen de un runtime externo (`support.js`) que no está incluido. Se leen como código fuente:

- El **marcado** usa estilos en línea (`style="..."`): de ahí salen colores, tamaños, radios, espaciados y textos exactos.
- `<sc-for list="{{x}}" as="y">` es un bucle y `{{y.campo}}` una variable; los valores están en el bloque `<script type="text/x-dc">`, dentro de `renderVals()`. Esos datos son **ficticios**: solo sirven para ver formato y longitud de los textos.
- `<sc-if value="{{...}}">` es un condicional.
- Los textos azules pequeños que empiezan con «NUEVO —» son notas de diseño y no se implementan.

Si algo de un mockup contradice `../ESPECIFICACION.md`, manda la especificación (sección 9).

| Archivo | Pantalla |
| --- | --- |
| `V3-Maestro.dc.html` | Pedidos (lista + ficha) |
| `M1-Dashboard.dc.html` | Dashboard |
| `M2-Fabricacion.dc.html` | Fabricación → Lotes de fabricación |
| `M2c-EnviarBodega.dc.html` | Fabricación → Lotes de fabricación con el modal «Enviar a bodega» |
| `M2b-ProduccionDiaria.dc.html` | Fabricación → Producción diaria |
| `R4-PedidosMasterDetail.dc.html` | Fabricación → Pedidos |
| `M3-Finanzas.dc.html` | Finanzas |
| `M4-Logistica.dc.html` | Logística → En tránsito |
| `M4b-ParaDespacho.dc.html` | Logística → Para despacho |
| `M4c-ArmarRuta.dc.html` | Logística con el modal «Nueva ruta» |
| `M5-Inventario.dc.html` | Inventario → Producto terminado |
| `M5b-MateriaPrima.dc.html` | Inventario → Materia prima |
| `R1-InventarioPedidos.dc.html` | Inventario → Pedidos |
| `M6-Catalogo.dc.html` | Catálogo |
| `M7-Empleados.dc.html` | Empleados → Personal |
| `M7b-Asistencia.dc.html` | Empleados → Asistencia |
| `M8-Configuracion.dc.html` | Configuración |
| `F1-FlujoPedido.dc.html` | Flujo de un pedido, hoy vs. propuesto (referencia, no es una pantalla) |
